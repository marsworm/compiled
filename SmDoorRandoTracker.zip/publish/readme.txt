made by marsworm twitch.tv/marsworm

-tracker auto saves on close

UI:
-area buttons focus on the named area
-door buttons select the color for missle/super/powerbomb doors
-beam buttons select the color for the respective beam door

keys:
-1-5 fast focus on area (crateria/brinstar etc)
-escape: clear all user objects like doors and item states
-z remove last placed door (undo list can press multiple times)

mouse:

-hold right mouse & move to pan the map
-left click on an item to mark it as picked up
-right click on an item to mark it as highlighted (from a non picked up state)
-left click anywhere to place a door in the current selected color