program by marsworm (https://twitch.tv/marsworm)

requirements:
windows
dotnet3.1 runtime: https://dotnet.microsoft.com/download/dotnet/3.1 to be installed


left click cycles through a items state (don't have-> out of logic ->inlogic)
right click to change a tracking item to inlogic right away

escape to clear everything
save state for segmented runs
